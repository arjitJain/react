const root = document.getElementById("root");
const heading = document.createElement("h1");
heading.innerHTML = "hello world";
root.appendChild(heading);
